import random
import itertools


POINTS_PER_GAME = 2


class Player(object):

    def __init__(self, name):
        self.name = name
        self.score = 0

    def add_win(self):
        self.score += POINTS_PER_GAME


class PlayerHand(object):

    def __init__(self, player, cards, game):
        self.player = player
        self.game = game
        self.hand = cards

    def play(self, card):
        if card not in self.hand:
            raise ValueError ('You don\'t have that card')
        self.game.play(self, card)
        self.game.hand.remove(card)


    def draw(self):
        self.hand.append(self.game.deal())


class CardGame(object):

    ranks = ['Sota', 'Copa', 'Moneda', 'Espada']
    values = ['1', '3', '4', '5', '6', '7', '8', '9', '10',
            'Principe', 'Caballo', 'Rey', '2']

    def __init__(self, players):
        self.participants = []
        self.winner = None
        self.act_player = None
        self.last_player = None
        self.last_card_played = None
        self.stock = Stock(ranks=len(self.ranks), values=len(self.values))
        self.deck = []
        self.turns = itertools.cycle(self.participants)
        initial_draw = int((len(self.stock.cards) * 0.5) / len(players))
        if initial_draw == 0:
            initial_draw = 1
        for p in players:
            cards = [self.stock.deal() for x in range(initial_draw)]
            self.participants.append(PlayerHand(p, cards, game=self))

    def start_game(self):
        self.act_player = self.turns.next()

    def play(self, player, card):
        if player != self.act_player:
            raise ('It isn\'nt your turn')
        if self.last_player.hand[-1] == self.last_player.hand[0]: 
            self.set_winner(last_player)
        if self.act_player == self.last_player or self.__cmp__(card):
            self.deck.append(card)
            self.last_card_played = card
            self.last_player = self.act_player
            self.act_player = self.turns.next()
        else:
            raise ('You can\'t make that play')

    def deal(self):
        draw = self.stock.deal()
        if not draw:
            self.stock = Stock(self.deck)
            self.deal() 
        self.last_player = self.act_player
        self.act_player = self.turns.next()
        return draw

    def set_winner(self, player):
        self.winner = player
        player.add_win()

    def __cmp__(self, other):
        if self.last_card_played.rank > other.rank:
            return 1
        elif self.last_card_played.rank == other.rank:
            if self.last_card_played.value > other.value:
                return 1
        return 0

    def show_card(self, card):
        return  (self.values[card.value] +' - '+ self.ranks[card.rank])

    def __json__(self, request):
        participants = self.participants
        winner = self.winner
        act_player = self.act_player
        last_player = self.last_player
        last_card_played = self.last_card_played



class Stock(object):

    def __init__(self, cards=None, ranks=None, values=None):
        if not cards:
            self.cards = []
            self.create(ranks, values)
            self.shuffle()
        else:
            self.cards = cards

    def create(self, ranks, values):
        for rank in range(ranks):
            for value in range(values):
                self.cards.append(Card(rank=rank, value=value))

    def shuffle(self):
        random.shuffle(self.cards)

    def deal(self):
        try:
            return self.cards.pop()
        except IndexError:
            return None


class Card(object):

    def __init__(self, rank, value):
        self.rank = rank
        self.value = value